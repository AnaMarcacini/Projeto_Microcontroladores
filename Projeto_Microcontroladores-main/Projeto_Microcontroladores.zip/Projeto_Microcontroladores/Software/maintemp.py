
# Importa as classes Pin e SPI da biblioteca machine para controlar o hardware do Raspberry Pi Pico
from machine import Pin, SPI
# Importa a classe SSD1306_SPI da biblioteca ssd1306.py
from Displays.Display_Pontuacao import 
